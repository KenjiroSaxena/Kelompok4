<?php
defined('BASEPATH') or exit('No direct script access allowed');


class Menu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Menu_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data['title'] = 'Menu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('menu', 'Menu', 'required');

        if ($this->form_validation->run() == false) {

            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar', $data);
            $this->load->view('template/topbar', $data);
            $this->load->view('menu/index', $data);
            $this->load->view('template/footer');
        } else {
            $this->db->insert('user_menu', ['menu' => $this->input->post('menu')]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> New menu added! </div>');
            redirect('menu');
        }
    }
    public function submenu()
    {
        $data['title'] = 'Submenu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->model('Menu_model', 'menu');

        $data['subMenu'] = $this->menu->getSubMenu();
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('menu_id', 'Menu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'Icon', 'required');


        if ($this->form_validation->run() == false) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar', $data);
            $this->load->view('template/topbar', $data);
            $this->load->view('menu/submenu', $data);
            $this->load->view('template/footer');
        } else {
            $data = [
                'title' => $this->input->post('title'),
                'menu_id' => $this->input->post('menu_id'),
                'url' => $this->input->post('url'),
                'icon' => $this->input->post('icon'),
                'is_active' => $this->input->post('is_active')
            ];
            $this->db->insert('user_sub_menu', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> New sub menu added! </div>');
            redirect('menu/submenu');
        }
    }

    public function insert()
    {
        $data['title'] = 'Insert Data';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['menu'] = $this->db->get('mahasiswa')->result_array();

        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('NIM', 'nim', 'required');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'required');
        $this->form_validation->set_rules('IPK', 'ipk', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar', $data);
            $this->load->view('template/topbar', $data);
            $this->load->view('menu/insert', $data);
            $this->load->view('template/footer');
        } else {
            $data = [
                'nama' => $this->input->post('nama'),
                'NIM' => $this->input->post('NIM'),
                'jurusan' => $this->input->post('jurusan'),
                'IPK' => $this->input->post('IPK')
            ];
            $this->db->insert('mahasiswa', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> New Data added! </div>');
            redirect('menu/insert');
        }
    }



    public function hapus($id)
    {
        $data['title'] = 'Submenu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->Menu_model->hapusData($id);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data Deleted successfully! </div>');
        redirect('menu/insert');
    }


    public function edit($id)
    {
        $data['title'] = 'Edit Data Mahasiswa';
        $data['menu'] = $this->db->get('mahasiswa')->result_array();

        $data['menu'] = $this->Menu_model->getDataById($id);
        $this->form_validation->set_rules('nama', 'Name', 'required');
        $this->form_validation->set_rules('NIM', 'nim', 'required');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'required');
        $this->form_validation->set_rules('IPK', 'ipk', 'required');

        if ($this->form_validation->run() == FALSE) {
            $data['user'] = $this->db->get_where('user', ['email' =>
            $this->session->userdata('email')])->row_array();
            $this->load->view('template/header', $data);
            $this->load->view('template/sidebar', $data);
            $this->load->view('template/topbar', $data);
            $this->load->view('menu/ubah', $data);
            $this->load->view('template/footer');
        } else {
            $this->Menu_model->ubahDataMahasiswa();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Data Edited successfully! </div>');
            redirect('menu/insert');
        }
    }
    public function chart()
    {
        $data['title'] = 'Chart';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('menu/chart', $data);
        $this->load->view('template/footer');
    }
    public function expdf()
    {
        $this->load->library('dompdf_gen');
        $data['mahasiswa'] = $this->Menu_model->getAllMahasiswa();

        $this->load->view('menu/laporan_pdf', $data);
        $paper_size = 'A4';
        $orientation = 'landscape';
        $mahasiswa = $this->output->get_output();
        $this->dompdf->set_paper($paper_size, $orientation);

        $this->dompdf->load_html($mahasiswa);
        $this->dompdf->render();
        $this->dompdf->stream("laporan_produk.pdf", array('Attachment' => 0));
    }

    public function exexcel()
    {
        $data['title'] = 'Laporan Data Mahasiswa';
        $data['mahasiswa'] = $this->Menu_model->getAllMahasiswa();
        $this->load->view('menu/exel', $data);
    }
    public function API()
    {
        $data['title'] = 'Rest API';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->view('template/header', $data);
        $this->load->view('template/sidebar', $data);
        $this->load->view('template/topbar', $data);
        $this->load->view('menu/API', $data);
        $this->load->view('template/footer');
    }
}
